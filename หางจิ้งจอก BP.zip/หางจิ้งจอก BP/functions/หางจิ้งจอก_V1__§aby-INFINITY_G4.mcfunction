give @s pa:model_fox_001_fi
