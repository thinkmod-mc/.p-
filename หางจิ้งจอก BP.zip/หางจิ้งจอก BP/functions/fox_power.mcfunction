effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.mainhand}] speed 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.offhand}] speed 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.mainhand}] strength 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.offhand}] strength 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.mainhand}] regeneration 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.offhand}] regeneration 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.mainhand}] resistance 2 0 true
effect @a[hasitem={item=pa:model_fox_001_fi,location=slot.weapon.offhand}] resistance 2 0 true